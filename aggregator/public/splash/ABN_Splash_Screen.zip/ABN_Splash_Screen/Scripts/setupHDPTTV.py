#!/usr/bin/python

# ------------------------------------------------------------------------------
# Designed for Python v2.7
# ------------------------------------------------------------------------------

# ------------------------------------------------------------------------------
# setupHDPTTV.py
# Purpose: Setup HD PTTV Device
# Release Date: 05 June 2018
# ------------------------------------------------------------------------------
__title__ = 'SETUP HD PTTV'
__author__ = 'Matthew Libby'
__copyright__ = 'Copyright 2017-2018, Automotive Broadcasting Network'
__credits__ = ['Matthew Libby']
__license__ = 'Internal Proprietary ABN License'
__version__ = '1.0.0'
__maintainer__ = 'Matthew Libby'
__email__ = 'matthew.libby@abnetwork.com'
__status__ = 'Production'
__name__ = 'SETUP_HD_PTTV'

# ------------------------------------------------------------------------------
# Includes
# ------------------------------------------------------------------------------
import os
import sys
import serial
import scalalib as sl
from scalatools import get_metaval
from scala5 import sharedvars
import traceback
import logging
from cStringIO import StringIO

reload(sys)
sys.setdefaultencoding("utf-8")

# ------------------------------------------------------------------------------
# Convert Scala Booleans to Python Boolean
# ------------------------------------------------------------------------------
def str_to_bool(s):
    if s == 'True' or s == 'On':
        return True
    elif s == 'False' or s == 'Off':
        return False
    elif s == 'None':
        return False
    else:
        raise ValueError(s)


def sendSerialCommands(cmdSet, pipDefaults, setupCmds=False):
    # Set COM defaults
    comPort = pipDefaults['hdCOMPort']
    comSettings = pipDefaults['comDefaults']
    baudRate = comSettings['baudRate']
    cmdDelay = comSettings['comDelay']

    # Open COM Port
    try:
        ser = serial.Serial(comPort, baudRate, timeout=1)
    except:
        comPort = autoDetectHDCOMPort(comSettings['cacheFile'], comSettings)
        log.info('[%s] (v%s): %s not available' % (__name__, __version__, port))

    ser.close()

    try:
        ser = serial.Serial(comPort, baudRate, timeout=1)
    except:
        log.info('[%s] (v%s): %s not available' % (__name__, __version__, port))

    ser.bytesize = comSettings['byteSize']
    ser.parity = comSettings['parity']
    ser.stopbits = comSettings['stopBits']

    for cmdStr in cmdSet:
        log.info('[%s] (v%s): Serial Port Command: %s' % (__name__, __version__, cmdStr))
        ser.write(cmdStr.encode('ascii') + '\r\n')
        response = ser.readline()
        log.info('[%s] (v%s): Serial Port Response: %s' % (__name__, __version__, response))
        sl.sleep(cmdDelay)

    if setupCmds:
        log.info('[%s] (v%s): Serial Port Command: Remove Border' % (__name__, __version__))
        ser.write(serial.to_bytes([0xa5, 0x5b, 0x0c, 0x01, 0xf0, 0x00, 0xf0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x13]))
        response = ser.readline()
        log.info('[%s] (v%s): Serial Port Response: %s' % (__name__, __version__, response))

    ser.close()


def autoDetectHDCOMPort(hdCacheFile, comSettings):
    # Set COM defaults
    baudRate = comSettings['baudRate']

    connected = False
    isOpen = False
    ports = ['COM%s' % (i + 1) for i in range(256)]
    result = []
    for port in ports:
        try:
            s = serial.Serial(port)
            s.close()
            result.append(port)
        except (OSError, serial.SerialException):
            pass

    for port in result:
        try:
            ser = serial.Serial(port, baudRate, timeout=1)
        except:
            log.info('[%s] (v%s): Detection: %s not available' % (__name__, __version__, port))
            continue

        ser.bytesize = comSettings['byteSize']
        ser.parity = comSettings['parity']
        ser.stopbits = comSettings['stopBits']

        try:
            if ser.isOpen():
                isOpen = True
        except:
            isOpen = False
            continue

        if isOpen:
            # Attempt to get device firmware version
            c = '?VERSION!'
            ser.write(c.encode('ascii') + '\r\n')
            # If COM port returns a firmware version
            if '.' and 'V' in ser.readline():
                # Write COM port to cache file
                fptr = open(hdCacheFile, 'w')
                fptr.write(str(port) + '\n')
                fptr.close()
                serialOutput = ser.get_settings()
                log.info('[%s] (v%s): %s is open' % (__name__, __version__, port))
                log.info('[%s] (v%s): Serial Port Settings: %s' % (__name__, __version__, serialOutput))
                break
            # else port did not return a known good response
            else:
                log.info('[%s] (v%s): Invalid Response From Port: %s' % (__name__, __version__, port))

    return port


def setupHDPTTV(pipDefaults):
    sendSerialCommands(pipDefaults['setupCommands'], pipDefaults, True)
    sendSerialCommands(pipDefaults['dtvCommands'], pipDefaults)


# ------------------------------------------------------------------------------
# Main
# ------------------------------------------------------------------------------

try:
    log = sl.get_logger(level='info', scala=1, con=1)
    log_stream = StringIO()
    logging.basicConfig(stream=log_stream, level=logging.INFO)

    scalaVars = sharedvars()

    debugScript = str_to_bool(str(get_metaval('Player.Script_Debugging')))

    if debugScript:
        log.info('[%s] (v%s): Starting' % (__name__, __version__))

    # Cache Directory
    cacheDir = 'D:\\temp\\'
    if not os.path.isdir(cacheDir):
        os.makedirs(cacheDir)

    # Cache Files
    cacheFile = {
        'hd_pttv_com_port': '%s\\hd_pttv_com_port.txt' % (cacheDir),
    }

    hdPTTV = str_to_bool(str(get_metaval('Player.HD_PTTV')))
    if debugScript:
        log.info('[%s] (v%s): HD PTTV Setting: %s' % (__name__, __version__, hdPTTV))

    if hdPTTV:
        comDefaults = {
            'baudRate': 115200,
            'byteSize': 8,
            'parity': 'N',
            'stopBits': 1,
            'comDelay': 600,
            'cacheFile': cacheFile['hd_pttv_com_port']
        }

        hdCOMPortCache = cacheFile['hd_pttv_com_port']
        detectCOM = False
        if os.path.isfile(hdCOMPortCache):
            if debugScript:
                log.info(
                    '[%s] (v%s): HD COM Port File: %s' % (
                        __name__, __version__, hdCOMPortCache))

            with open(hdCOMPortCache) as f:
                content = f.readlines()

            content = [x.strip() for x in content]
            if len(content) > 0:
                hdCOMPort = content[0]
                detectCOM = False
                if debugScript:
                    log.info(
                        '[%s] (v%s): Reading Line from HD COM Port: %s' % (
                            __name__, __version__, content[0]))
            else:
                detectCOM = True
                if debugScript:
                    log.info(
                        '[%s] (v%s): HD COM Port Cache File is Invalid.  Need to Build: %s' % (
                            __name__, __version__, hdCOMPortCache))

        else:
            detectCOM = True

        if detectCOM:
            hdCOMPort = autoDetectHDCOMPort(hdCOMPortCache, comDefaults)

        pttvDefaults = {
            'setupCommands': ['T1!', 'AM1!'],
            'dtvCommands': ['IA1!', 'IN1!', 'ONEINPUT1!'],
            'pipCommands': ['IA2!', 'IN1!', 'PIP!'],
            'hdCOMPort': hdCOMPort,
            'comDefaults': comDefaults
        }
        setupHDPTTV(pttvDefaults)

except:
    pass

try:
    log = sl.get_logger(level='info', scala=1)
    s = log_stream.getvalue().split('\n')
    for line in s:
        if ":" in line:
            splitLine = line.split(":",1)
            if splitLine[0] == "INFO":
                log.info(splitLine[1])
            elif splitLine[0] == "WARNING":
                log.warn(splitLine[1])
            elif splitLine[0] == "ERROR":
                log.error(splitLine[1])
            else:
                log.info(line)

except:
    log.warn('[%s] (v%s): %s' % (__name__, __version__, traceback.format_exc()))
    pass
