#!/usr/bin/python

#------------------------------------------------------------------------------
# localDataShare.py
# Purpose: To gather data from local computer for splash screen
# Release Date: 04 April 2018
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# License
#
# Copyright (c) 2018 Matthew Libby
# For internal development by employees of ABN
#------------------------------------------------------------------------------
__author__ = 'Matthew J. Libby'
__copyright__ = 'Copyright 2018, Matthew J. Libby'
__credits__ = ['Matthew J. Libby']
__license__ = 'Private'
__version__ = '1.0'
__maintainer__ = 'Matthew J. Libby'
__email__ = 'matthew.libby@abnetwork.com'
__status__ = 'Development'


#------------------------------------------------------------------------------
# Includes
#------------------------------------------------------------------------------
import collections
import ctypes
from ctypes import wintypes
import datetime
import json
import locale
import os
from os import path, access, R_OK
import platform
import re
import shutil
import socket
import string
import sys
import time
import traceback
import win32api as win32
import win32com.client
from difflib import SequenceMatcher
from time import gmtime, strftime
from scala5 import sharedvars
import win32con
import win32evtlog
import win32evtlogutil
import win32security
import win32serviceutil

reload(sys)
sys.setdefaultencoding("utf-8")


def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()


def diskUsage(path):
    _ntuple_diskusage = collections.namedtuple('usage', 'total used free')

    _, total, free = ctypes.c_ulonglong(), ctypes.c_ulonglong(), \
                     ctypes.c_ulonglong()
    if sys.version_info >= (3,) or isinstance(path, unicode):
        fun = ctypes.windll.kernel32.GetDiskFreeSpaceExW
    else:
        fun = ctypes.windll.kernel32.GetDiskFreeSpaceExA
    ret = fun(path, ctypes.byref(_), ctypes.byref(total), ctypes.byref(free))
    if ret == 0:
        raise ctypes.WinError()
    used = total.value - free.value
    return _ntuple_diskusage(total.value, used, free.value)


def bytes2human(n):
    symbols = ('K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y')
    prefix = {}
    for i, s in enumerate(symbols):
        prefix[s] = 1 << (i+1)*10
    for s in reversed(symbols):
        if n >= prefix[s]:
            value = float(n) / prefix[s]
            return '%.1f%s' % (value, s)
    return "%sB" % n


def percentage(part, whole):
    return 100 * float(part)/float(whole)


def date2sec(evt_date):
    regexp = re.compile('(.*)\s(.*)')
    reg_result = regexp.search(evt_date)
    date = reg_result.group(1)
    the_time = reg_result.group(2)
    (mon, day, yr) = map(lambda x: string.atoi(x), string.split(date, '/'))
    (hr, min, sec) = map(lambda x: string.atoi(x), string.split(the_time, ':'))
    tup = [yr, mon, day, hr, min, sec, 0, 0, 0]
    sec = time.mktime(tup)
    return sec


def getMAC():
    mac = ''
    output = os.popen("ipconfig /all")
    for line in output:
        if line.lstrip().startswith('Physical Address'):
            mac = line.split(':')[1].strip().replace('-', ':')
            return mac


def isGoodIP(s):
    pieces = s.split('.')
    if len(pieces) != 4: return False
    try:
        return all(0 <= int(p) < 256 for p in pieces)
    except ValueError:
        return False

def getIPInfo():
    ipInfo = {'ipAddress': '0.0.0.0', 'subnetMask': '0.0.0.0', 'defaultGateway': '0.0.0.0'}
    ipFilled = False
    smFilled = False
    gwFilled = False
    output = os.popen("ipconfig /all")
    for line in output:
        if line.lstrip().startswith('IPv4 Address'):
            tempIP = line.split(':')[1].strip().replace('-', ':').replace('(Preferred)', '')
            if isGoodIP(tempIP):
                ipInfo['ipAddress'] = tempIP
                ipFilled = True

        if line.lstrip().startswith('Subnet Mask'):
            tempSM = line.split(':')[1].strip().replace('-', ':')
            if isGoodIP(tempSM):
                ipInfo['subnetMask'] = tempSM
                smFilled = True

        if line.lstrip().startswith('Default Gateway'):
            tempGW = line.split(':')[1].strip().replace('-', ':')
            if isGoodIP(tempGW):
                ipInfo['defaultGateway'] = tempGW
                gwFilled = True

        if ipFilled and smFilled and gwFilled:
            break

    return ipInfo

def getDNSServers():
    dns = []
    output = os.popen("ipconfig /all")
    for line in output:
        if line.lstrip().startswith('DNS Servers'):
            tempDNS = line.split(':')[1].strip().replace('-', ':')
            if isGoodIP(tempDNS):
                dns.append(tempDNS)
            tempDNS = next(output).strip()
            if isGoodIP(tempDNS):
                dns.append(tempDNS)
            return dns


def checkServer(address, port):
    # Create a TCP socket
    s = socket.socket()
    # print "Attempting to connect to %s on port %s" % (address, port)
    try:
    	s.connect((address, port))
        # print "Connected to %s on port %s" % (address, port)
        return True
    except socket.error, e:
        # print "Connection to %s on port %s failed: %s" % (address, port, e)
        return False


def getTimezone():
    sysTimezone = strftime("%Z", gmtime())
    tempTZ = ""
    for i in sysTimezone.upper().split():
        tempTZ += i[0]

    return tempTZ


def getWindowsResolution():
    user32 = ctypes.windll.user32
    user32.SetProcessDPIAware()
    hRes = user32.GetSystemMetrics(0)
    vRes = user32.GetSystemMetrics(1)

    if hRes == 1804:
        hRes = 1920
    elif hRes == 1014:
        hRes = 1080

    if vRes == 1804:
        vRes = 1920
    elif vRes == 1014:
        vRes = 1080

    return str(hRes) + "x" + str(vRes)


def getMonitorName():
    monitors = []

    try:
        for hMonitor, hdcMonitor, pyRect in win32.EnumDisplayMonitors():
            monitors.append(win32.EnumDisplayDevices(win32.GetMonitorInfo(hMonitor)["Device"], 0))

        for items in monitors:
            return items.DeviceString

    except win32.error:
        return "None"
        pass


def readEventLog(server, log_type):
    begin_sec = time.time()
    begin_time = time.strftime('%H:%M:%S  ', time.localtime(begin_sec))
    number_of_hours_to_look_back = 336

    seconds_per_hour = 60 * 60
    how_many_seconds_back_to_search = seconds_per_hour * number_of_hours_to_look_back

    gathered_events = []
    gathered_times = []

    try:
        log_handle = win32evtlog.OpenEventLog(server, log_type)

        total = win32evtlog.GetNumberOfEventLogRecords(log_handle)
        """
        print("Scanning through {} events on {} in {}".format(total, server, log_type))
        """

        flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ

        event_count = 0
        events = 1
        while events:
            events = win32evtlog.ReadEventLog(log_handle, flags, 0)
            seconds = begin_sec
            for event in events:
                the_time = event.TimeGenerated.Format()
                seconds = date2sec(the_time)
                if seconds < begin_sec - how_many_seconds_back_to_search:
                    break

                answer = event.EventID & 0x1FFFFFFF
                if answer == 6005:
                    gathered_times.append(the_time)

                if event.EventType == win32con.EVENTLOG_ERROR_TYPE:
                    event_count += 1
                    gathered_events.append(event)
            if seconds < begin_sec - how_many_seconds_back_to_search: break  # get out of while loop as well

        win32evtlog.CloseEventLog(log_handle)
    except:
        try:
            print(traceback.print_exc(sys.exc_info()))
        except:
            print('Exception while printing traceback')

    return gathered_times


def checkASC():
    try:
        win32serviceutil.QueryServiceStatus('ASC')[1] == 4
        return True
    except:
        return False


def getReboots():
    import datetime

    psCommand = 'get-eventlog system | where-object {$_.eventid -eq 6005} | select TimeGenerated -first 10'
    result = os.popen('powershell.exe -NoProfile -Command "' + psCommand + '"').read()
    gatheredEvents = [];
    for workLine in result.splitlines():
        if workLine:
            if workLine[0].isdigit():
                print workLine.strip()
                try:
                    workTime = datetime.datetime.strptime(workLine.strip(), '%m/%d/%Y %I:%M:%S %p')
                except ValueError:
                    workTime = False
                if workTime:
                    retTime = workTime.strftime('%m/%d/%Y %H:%M:%S')
                    gatheredEvents.append(retTime)

    return gatheredEvents


def dump(obj):
   for attr in dir(obj):
       if hasattr( obj, attr ):
           print( "obj.%s = %s" % (attr, getattr(obj, attr)))


scriptPath = "D:\\ABN_Splash_Screen"
scalaVars = sharedvars()

"""
Archive Support Log Files
"""
logsPath = scriptPath + '\\Diagnostics\\'
if os.path.isfile(logsPath + 'SplashDiagnostics.5.txt'):
    os.remove(logsPath + 'SplashDiagnostics.5.txt')

if os.path.isfile(logsPath + 'SplashDiagnostics.4.txt'):
    os.rename(logsPath + 'SplashDiagnostics.4.txt', logsPath + 'SplashDiagnostics.5.txt')

if os.path.isfile(logsPath + 'SplashDiagnostics.3.txt'):
    os.rename(logsPath + 'SplashDiagnostics.3.txt', logsPath + 'SplashDiagnostics.4.txt')

if os.path.isfile(logsPath + 'SplashDiagnostics.2.txt'):
    os.rename(logsPath + 'SplashDiagnostics.2.txt', logsPath + 'SplashDiagnostics.3.txt')

if os.path.isfile(logsPath + 'SplashDiagnostics.1.txt'):
    os.rename(logsPath + 'SplashDiagnostics.1.txt', logsPath + 'SplashDiagnostics.2.txt')

if os.path.isfile(logsPath + 'SplashDiagnostics.txt'):
    os.rename(logsPath + 'SplashDiagnostics.txt', logsPath + 'SplashDiagnostics.1.txt')

"""
Open Current Support Log File
"""
f = open(logsPath + 'SplashDiagnostics.txt', 'w+')
currentDate = str(time.strftime("%A, %B %d, %Y %H:%M:%S"))
f.write("ABN_Splash_Screen_Player_Diagnostic_Logs\r\n")
f.write("Current_Log_Date::%s\r\n" % (currentDate))

sysComputerName = socket.gethostname()
scalaVars.computerName = sysComputerName
f.write("Windows_Name::%s\r\n" % (sysComputerName))
f.write("Scala_Name::%s\r\n" % (scalaVars.scalaPlayerName))
scalaVars.windowsResolution = getWindowsResolution()
f.write("Windows_Resolution::%s\r\n" % (getWindowsResolution()))
scalaResolution = str(scalaVars.scalaConfiguredWidth) + "x" + str(scalaVars.scalaConfiguredHeight)
f.write("Scala_Resolution::%s\r\n" % (scalaResolution))
scalaVars.computerTimeZone = getTimezone()
f.write("Timezone::%s\r\n" % (getTimezone()))

tempString = str(scalaVars.scalaVersion)
scalaVars.scalaVersion = string.replace(tempString, "Release ", "")
f.write("Scala_Version::%s\r\n" % (scalaVars.scalaVersion))

scalaVars.pythonVersion = platform.python_version()
f.write("Python_Version::%s\r\n" % (platform.python_version()))

ipResults = getIPInfo()
tempIPAddress = ipResults['ipAddress']
tempSubnetMask = ipResults['subnetMask']
tempDefaultGateway = ipResults['defaultGateway']

scalaVars.ipAddress = tempIPAddress
scalaVars.subnetMask = tempSubnetMask
scalaVars.defaultGateway = tempDefaultGateway

dnsList = getDNSServers()
dnsText = ""
dnsLogText = ""

for dnsEntry in dnsList:
    dnsText += str(dnsEntry)
    dnsText += "\n"
    dnsLogText += str(dnsEntry)
    dnsLogText += " "

scalaVars.dnsServers = dnsText

tempMACAddress = getMAC()

f.write("IP_Address::%s\r\n" % (str(tempIPAddress)))
f.write("Subnet_Mask::%s\r\n" % (str(tempSubnetMask)))
f.write("Default_Gateway::%s\r\n" % (str(tempDefaultGateway)))
f.write("DNS_Servers::%s\r\n" % (dnsLogText))
scalaVars.macAddress = str(tempMACAddress)
f.write("MAC_Address::%s\r\n" % (str(tempMACAddress)))

prettyDate = time.strftime("%A\n%B %d, %Y")
scalaVars.formattedDate = prettyDate

"""
Get drive usage for C: and D:
"""
cDrive = diskUsage("C:/")
dDrive = diskUsage("D:/")
scalaVars.cDriveTotal = str(bytes2human(cDrive.total))
f.write("C_Drive_Total::%s\r\n" % (scalaVars.cDriveTotal))
f.write("C_Drive_Free::%s\r\n" % (str(bytes2human(cDrive.free))))
f.write("C_Drive_Percent_Free::%.2f\r\n" % (percentage(cDrive.free, cDrive.total)))
scalaVars.dDriveTotal = str(bytes2human(dDrive.total))
f.write("D_Drive_Total::%s\r\n" % (scalaVars.dDriveTotal))
f.write("D_Drive_Free::%s\r\n" % (str(bytes2human(dDrive.free))))
f.write("D_Drive_Percent_Free::%.2f\r\n" % (percentage(dDrive.free, dDrive.total)))
scalaVars.cDriveFree = str(bytes2human(cDrive.free)) + " Free"
scalaVars.dDriveFree = str(bytes2human(dDrive.free)) + " Free"
cPercentFree = percentage(cDrive.free, cDrive.total)
dPercentFree = percentage(dDrive.free, dDrive.total)
if (cPercentFree > 10):
    scalaVars.cDriveIcon = scriptPath +  '\SharedAssets\icon_harddrive_success.png'
else:
    scalaVars.cDriveIcon = scriptPath + '\SharedAssets\icon_harddrive_failed.png'

if (dPercentFree > 10):
    scalaVars.dDriveIcon = scriptPath + '\SharedAssets\icon_harddrive_success.png'
else:
    scalaVars.dDriveIcon = scriptPath + '\SharedAssets\icon_harddrive_failed.png'

"""
Test network connectivity to ABN servers
"""
testFeeds = checkServer('scalafeeds.abnetwork.com', 80)
if (testFeeds):
    scalaVars.feedsTest = scriptPath + '\SharedAssets\icon_network_success.png'
    f.write("Feeds_Connect::True\r\n")
else:
    scalaVars.feedsTest = scriptPath + '\SharedAssets\icon_network_failed.png'
    f.write("Feeds_Connect::False\r\n")

testESB = checkServer('prod.abnesb.com', 80)
if (testESB):
    scalaVars.esbTest = scriptPath + '\SharedAssets\icon_network_success.png'
    f.write("ESB_Connect::True\r\n")
else:
    scalaVars.esbTest = scriptPath + '\SharedAssets\icon_network_failed.png'
    f.write("ESB_Connect::False\r\n")

testABNLive = checkServer('app.abn.live', 443)
if (testABNLive):
    scalaVars.abnLiveTest = scriptPath + '\SharedAssets\icon_network_success.png'
    f.write("Live_Connect::True\r\n")
else:
    scalaVars.abnLiveTest = scriptPath + '\SharedAssets\icon_network_failed.png'
    f.write("Live_Connect::False\r\n")

"""
End network connectivity testing
"""


"""
List scheduled tasks and search for Weekly Reboot, Daily Reboot, ASD, and APC
"""
valuePlayerControl = scriptPath + '\SharedAssets\icon_apc_failed.png'
valueWeeklyReboot = scriptPath + '\SharedAssets\icon_weekly_failed.png'

scheduler = win32com.client.Dispatch("Schedule.Service")

# list user task only
# scheduler.Connect()
# list all task use (requires full administrator rights)
# scheduler.Connect("localhost")
scheduler.Connect()

objTaskFolder = scheduler.GetFolder("\\")
colTasks = objTaskFolder.GetTasks(1)

for task in colTasks:
    playerControlMatch = similar('ASD', task.Name) * 100
    if playerControlMatch > 99:
        valuePlayerControl = scriptPath + '\SharedAssets\icon_apc_success.png'

    weeklyRebootMatch = similar('Weekly_Player_Reboot', task.Name) * 100
    if weeklyRebootMatch > 99:
        valueWeeklyReboot = scriptPath + '\SharedAssets\icon_weekly_success.png'

scalaVars.playerControlTest = valuePlayerControl
scalaVars.weeklyRebootTest = valueWeeklyReboot
"""
End scheduled tasks search
"""

"""
Check ASC
"""
valueScreenControl = scriptPath + '\SharedAssets\icon_asc_failed.png'
screenControlMatch = checkASC()
if screenControlMatch:
    valueScreenControl = scriptPath + '\SharedAssets\icon_asc_success.png'
else:
    valueScreenControl = scriptPath + '\SharedAssets\icon_asc_failed.png'

scalaVars.screenControlTest = valueScreenControl
"""
End ASC Check
"""

"""
List running processes and search for TeamViewer and SolarWinds
"""
valueTeamViewer = scriptPath + '\SharedAssets\icon_teamviewer_failed.png'
valueSolarWinds = scriptPath + '\SharedAssets\icon_solarwinds_failed.png'


wmi = win32com.client.GetObject('winmgmts:')
for p in wmi.InstancesOf('win32_process'):
    teamViewerMatch = similar('TeamViewer.exe', p.Name) * 100
    if teamViewerMatch > 99:
        valueTeamViewer = scriptPath + '\SharedAssets\icon_teamviewer_success.png'

    solarWindsMatch = similar('BASupSrvc.exe', p.Name) * 100
    if solarWindsMatch > 99:
        valueSolarWinds = scriptPath + '\SharedAssets\icon_solarwinds_success.png'

scalaVars.teamViewerTest = valueTeamViewer
scalaVars.solarWindsTest = valueSolarWinds
"""
End running processes search
"""

"""
Log installed programs
"""

if "failed" not in scalaVars.playerControlTest:
    f.write("ABN_Player_Control_Installed::True\r\n")
else:
    f.write("ABN_Player_Control_Installed::False\r\n")

if "failed" not in scalaVars.screenControlTest:
    f.write("ABN_Screen_Control_Installed::True\r\n")
else:
    f.write("ABN_Screen_Control_Installed::False\r\n")

if "failed" not in scalaVars.weeklyRebootTest:
    f.write("Weekly_Reboot_Installed::True\r\n")
else:
    f.write("Weekly_Reboot_Installed::False\r\n")

if "failed" not in scalaVars.teamViewerTest:
    f.write("TeamViewer_Installed::True\r\n")
else:
    f.write("TeamViewer_Installed::False\r\n")

if "failed" not in scalaVars.solarWindsTest:
    f.write("SolarWinds_Installed::True\r\n")
else:
    f.write("SolarWinds_Installed::False\r\n")

"""
End log installed programs
"""

"""
Get Active Monitor from Python Function
print getMonitorName()
"""

"""
Write pageDuration from Player Metadata
"""
f.write("SplashTimer::%s\r\n" % (scalaVars.pageDuration))


"""
Get list of last Windows reboots
"""
rebootTimes = getReboots()
try:
    scalaVars.lastReboot = rebootTimes[0]
except:
    scalaVars.lastReboot = "None Detected"

f.write("Reboot_List_from_Event_Log::\r\n")
for rTime in rebootTimes:
    f.write(rTime + "\r\n")

f.write("::End_Reboot_List_from_Event_Log\r\n")
f.close()


