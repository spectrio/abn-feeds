#!/usr/bin/python

#------------------------------------------------------------------------------
# metaDataShare.py
# Purpose: To gather data from player metadata for splash screen
# Release Date: 04 April 2018
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# License
#
# Copyright (c) 2018 Matthew Libby
# For internal development by employees of ABN
#------------------------------------------------------------------------------
__author__ = 'Matthew J. Libby'
__copyright__ = 'Copyright 2018, Matthew J. Libby'
__credits__ = ['Matthew J. Libby']
__license__ = 'Private'
__version__ = '1.0'
__maintainer__ = 'Matthew J. Libby'
__email__ = 'matthew.libby@abnetwork.com'
__status__ = 'Development'


#------------------------------------------------------------------------------
# Includes
#------------------------------------------------------------------------------
import os
from scalatools import get_metaval
from scala5 import sharedvars

scriptPath = "D:\\ABN_Splash_Screen"
scalaVars = sharedvars()
locID = get_metaval('Player.Location_ID')

"""
Open timer.txt to determine splash duration
"""
timerFile = scriptPath + "\\timer.txt"

if not os.path.isfile(timerFile):
    f = open(timerFile, 'w+')
    f.write("0\r\n")
    f.close()

with open(timerFile) as f:
    content = f.readlines()

f.close()

content = [x.strip() for x in content]
if len(content) > 0:
    evalTimer = content[0]
else:
    evalTimer = 0

if evalTimer == 'QC':
    scalaVars.pageDuration = 86400
else:
    scalaVars.pageDuration = int(evalTimer)

"""
End timer.txt to determine splash duration
"""

scalaVars.locationID = locID
scalaVars.screenRotation = locID[13]
orientationOptions = {
	'H': 'Horizontal',
	'V': 'Vertical',
}
try:
	screenOrientation = orientationOptions[locID[13]]
except:
	screenOrientation = "Other Orientation"
	
screenOptions = {
    'DS': 'Digital Signage',
    'MB': 'Menu Board',
    'DT': 'Dealer TV',
    'VW': 'Video Wall',
	'DB': 'Delivery Board',
	'CP': 'Control PC',
}
try:
	screeenType = screenOptions[locID[11:13]]
except:
	screenType = "Other Type"
	
scalaVars.screenDescription = screenOrientation + " " + screeenType
locationOptions = {
    'CA': 'Cafe',
    'CC': 'Collision Center',
    'DB': 'Delivery Bay',
    'EA': 'Employee Area',
    'FI': 'F&I',
    'MA': 'Multiple Areas',
    'OT': 'Other',
    'PA': 'Parts & Accessories',
    'QL': 'Quick Lane',
    'SS': 'Sales Associate Area',
    'SA': 'Service Advisor Area',
    'SD': 'Service Drive',
    'SL': 'Service Lane',
    'SW': 'Service Waiting Area',
    'SH': 'Showroom',
    'UC': 'Used Cars'
}
try:
	plrLocation = locationOptions[locID[2:4]]
except:
	plrLocation = "Other Area"
	
scalaVars.playerLocation = plrLocation
